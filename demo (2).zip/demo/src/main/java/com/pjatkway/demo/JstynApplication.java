package com.pjatkway.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JstynApplication {

	public static void main(String[] args) {
		SpringApplication.run(JstynApplication.class, args);
	}

}
